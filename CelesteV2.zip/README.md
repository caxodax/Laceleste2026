# 🍔 La Celeste - Sistema Web para Restaurante (V2)

Sistema web premium para **La Celeste**, restaurante de hamburguesas artesanales en Barquisimeto, Venezuela. Refactorizado para máxima transparencia legal, dinamización administrativa e integración financiera BCV.

![La Celeste](https://img.shields.io/badge/La%20Celeste-Hamburguesas-0ea5e9?style=for-the-badge)
![Next.js](https://img.shields.io/badge/Next.js-14-black?style=for-the-badge&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue?style=for-the-badge&logo=typescript)
![Supabase](https://img.shields.io/badge/Supabase-Database-3ecf8e?style=for-the-badge&logo=supabase)

## ✨ Características Actuales

### 🌟 Dinamización Total (CMS Integrado)
- 🖼️ **Hero Section:** Configurable con imagen única o carrusel de hasta 3 imágenes desde el admin.
- 📖 **Sección "Nosotros":** Gestión dinámica de texto corporativo e imagen de marca.
- 📱 **Contacto Centralizado:** Sincronización en tiempo real de WhatsApp, Instagram, Teléfono y Email.

### 💰 Finanzas e Integración BCV
- 🇻🇪 **Tasa BCV:** Integración con API externa para tasas en tiempo real de Bolívares.
- ⚙️ **Control de Tasa:** Alternancia entre Tasa Automática o Tasa Manual (Override) en el admin.
- 💵 **Doble Divisa:** Visualización automática de totales en Bolívares (Bs.) y Dólares ($) en checkout y admin.
- 🧾 **Gestión de Impuestos:** Configura IVA y Delivery con controles de activación inmediata.

### 🛡️ Transparencia Legal (SENIAT Compliance)
- 📝 **Notas de Entrega:** Refactorización total para control interno, evitando terminología de "Factura".
- ⚠️ **Disclaimer Legal:** Inclusión de la leyenda obligatoria *"ESTO NO ES UNA FACTURA FISCAL"*.
- 🚫 **Sin Pedido Mínimo:** Se eliminaron las restricciones de monto mínimo para facilitar las ventas.

### 🛠️ Para Administradores
- 📊 **Dashboard:** Métricas rápidas de ventas, pedidos recientes y KPIs de gestión.
- 📦 **Gestión de Comprobantes:** Generación manual de notas de entrega y listado histórico.
- 🍔 **Gestión de Menú:** CRUD completo de productos, categorías y disponibilidad instantánea.
- ⚙️ **Configuración Global:** Control total de la identidad visual y financiera sin tocar código.

## 🚀 Tecnologías

- **Framework:** Next.js 14 (App Router)
- **Base de Datos & Auth:** Supabase (PostgreSQL)
- **Almacenamiento:** Supabase Storage (Fotos de productos y banners)
- **Estado Global:** Zustand
- **Animaciones:** Framer Motion (Diseño premium y fluido)
- **Estilos:** Tailwind CSS con paleta personalizada
- **Formularios:** React Hook Form + Zod
- **API Moneda:** ve.dolarapi.com (Tasa Oficial BCV)

## 📦 Instalación

### Prerrequisitos
- Node.js 18+
- Instancia activa de Supabase

### Pasos

1. **Clonar el repositorio**
```bash
git clone <repo-url>
cd la-celeste-web
```

2. **Instalar dependencias**
```bash
npm install
```

3. **Configurar variables de entorno**
Crea un archivo `.env.local` con tus claves de Supabase:
```env
NEXT_PUBLIC_SUPABASE_URL=tu_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_anon_key
```

4. **Base de Datos**
Ejecuta el script `schema.sql` en el SQL Editor de tu Dashboard de Supabase para inicializar tablas, RLS y funciones.

5. **Iniciar en desarrollo**
```bash
npm run dev
```

## 📁 Estructura del Proyecto

```
la-celeste-web/
├── src/
│   ├── app/                    # App Router (Páginas y API)
│   │   ├── admin/             # Panel Administrativo Protegido
│   │   │   ├── notas-entrega/ # Control interno de ventas
│   │   │   ├── configuracion/ # CMS y Finanzas
│   │   │   └── productos/     # CRUD de menú
│   │   ├── pedido/            # Checkout dinámico ($ / Bs.)
│   │   └── ...
│   ├── components/
│   │   ├── ui/                # Design System atómico
│   │   ├── layout/            # Componentes estructurales dinámicos
│   │   └── ...
│   ├── lib/
│   │   ├── services/          # Conectores Supabase y API de cambio
│   │   └── supabase/          # Cliente Supabase
│   ├── store/
│   │   ├── settingsStore.ts   # Estado global de configuración
│   │   └── cartStore.ts       # Lógica persistente del carrito
│   └── types/                 # Typings estrictos de TypeScript
├── schema.sql                 # Estructura PostgreSQL (Supabase)
└── tailwind.config.ts         # Tokens de marca (Celeste/Gold)
```

## 🎨 Identidad Visual (Design System)

- **Celeste:** `#0ea5e9` - Vitalidad y frescura.
- **Gold:** `#eab308` - Elegancia artesanal y acento de calidad.
- **Cream:** `#fdf8f0` - Fondo equilibrado para experiencia "gourmet".

## 📄 Licencia

Este proyecto es propiedad privada de **La Celeste**. El despliegue está optimizado para Vercel y Supabase.

---
Desarrollado con ❤️ para La Celeste 🍔 | Barquisimeto, Venezuela
