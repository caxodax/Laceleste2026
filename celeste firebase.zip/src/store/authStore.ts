import { create } from 'zustand';
import { 
  signInWithEmailAndPassword, 
  signOut as firebaseSignOut,
  onAuthStateChanged 
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';
import { User } from '@/types';

interface AuthStore {
  user: User | null;
  loading: boolean;
  error: string | null;
  initialized: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  initAuth: () => () => void;
  clearError: () => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  loading: false,
  error: null,
  initialized: false,

  signIn: async (email: string, password: string) => {
    set({ loading: true, error: null });
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
      
      if (userDoc.exists()) {
        const userData = userDoc.data() as Omit<User, 'id'>;
        set({ 
          user: { id: userCredential.user.uid, ...userData },
          loading: false 
        });
      } else {
        // Usuario autenticado pero sin documento en Firestore
        set({ 
          user: {
            id: userCredential.user.uid,
            email: userCredential.user.email || '',
            displayName: userCredential.user.displayName || 'Usuario',
            role: 'customer',
            createdAt: new Date(),
          },
          loading: false 
        });
      }
    } catch (error: any) {
      let errorMessage = 'Error al iniciar sesión';
      if (error.code === 'auth/user-not-found') {
        errorMessage = 'Usuario no encontrado';
      } else if (error.code === 'auth/wrong-password') {
        errorMessage = 'Contraseña incorrecta';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Email inválido';
      }
      set({ error: errorMessage, loading: false });
      throw error;
    }
  },

  signOut: async () => {
    set({ loading: true });
    try {
      await firebaseSignOut(auth);
      set({ user: null, loading: false });
    } catch (error) {
      set({ error: 'Error al cerrar sesión', loading: false });
      throw error;
    }
  },

  initAuth: () => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (userDoc.exists()) {
            const userData = userDoc.data() as Omit<User, 'id'>;
            set({ 
              user: { id: firebaseUser.uid, ...userData },
              initialized: true,
              loading: false 
            });
          } else {
            set({ 
              user: {
                id: firebaseUser.uid,
                email: firebaseUser.email || '',
                displayName: firebaseUser.displayName || 'Usuario',
                role: 'customer',
                createdAt: new Date(),
              },
              initialized: true,
              loading: false 
            });
          }
        } catch (error) {
          set({ user: null, initialized: true, loading: false });
        }
      } else {
        set({ user: null, initialized: true, loading: false });
      }
    });

    return unsubscribe;
  },

  clearError: () => set({ error: null }),
}));
