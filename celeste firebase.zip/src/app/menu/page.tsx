'use client';

import { motion } from 'framer-motion';
import { Header, Footer, WhatsAppButton } from '@/components/layout';
import { MenuSection, CategoryNav } from '@/components/menu';
import { products, categories } from '@/data/menu';

export default function MenuPage() {
  return (
    <>
      <Header />
      
      <main className="pt-20">
        {/* Hero */}
        <section className="bg-gradient-to-r from-celeste-600 to-celeste-700 py-16">
          <div className="container-app text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="heading-1 text-white mb-4">Nuestro Menú</h1>
              <p className="text-xl text-white/90 max-w-2xl mx-auto">
                Descubre todas nuestras deliciosas opciones. 
                Hamburguesas artesanales, tequeños, postres y más.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Category Navigation */}
        <CategoryNav categories={categories} />

        {/* Menu Sections */}
        <div className="container-app py-8">
          {categories.map((category) => {
            const categoryProducts = products.filter(
              (p) => p.category === category.id
            );
            if (categoryProducts.length === 0) return null;
            
            return (
              <MenuSection
                key={category.id}
                category={category}
                products={categoryProducts}
              />
            );
          })}
        </div>
      </main>

      <Footer />
      <WhatsAppButton />
    </>
  );
}
