'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Search,
  Filter,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  Truck,
  ChefHat,
  Package,
} from 'lucide-react';
import { Button, Input, Card, CardContent, OrderStatusBadge, Modal } from '@/components/ui';
import { formatCurrency, formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';

// Datos de ejemplo
const orders = [
  {
    id: 'ORD-001',
    customer: 'María García',
    phone: '0412-1234567',
    items: [
      { name: 'La Bombonera', quantity: 2, price: 9.50 },
      { name: 'Tequeños 10 uds', quantity: 1, price: 5.00 },
    ],
    total: 24.00,
    status: 'pending' as const,
    deliveryType: 'delivery',
    address: 'Av. Venezuela, Edificio Torre Sol, Piso 5',
    paymentMethod: 'Pago Móvil',
    createdAt: new Date(Date.now() - 5 * 60000),
  },
  {
    id: 'ORD-002',
    customer: 'Carlos Rodríguez',
    phone: '0414-9876543',
    items: [
      { name: 'San Telmo', quantity: 1, price: 8.50 },
      { name: 'Refresco 355ml', quantity: 2, price: 1.50 },
    ],
    total: 11.50,
    status: 'confirmed' as const,
    deliveryType: 'pickup',
    paymentMethod: 'Efectivo',
    createdAt: new Date(Date.now() - 15 * 60000),
  },
  {
    id: 'ORD-003',
    customer: 'Ana Martínez',
    phone: '0424-5551234',
    items: [
      { name: 'La Monumental', quantity: 3, price: 10.00 },
      { name: 'Brookies', quantity: 2, price: 3.00 },
    ],
    total: 36.00,
    status: 'preparing' as const,
    deliveryType: 'delivery',
    address: 'Urb. El Parque, Casa 15',
    paymentMethod: 'Zelle',
    createdAt: new Date(Date.now() - 30 * 60000),
  },
  {
    id: 'ORD-004',
    customer: 'Luis Pérez',
    phone: '0416-7778899',
    items: [
      { name: 'Caballito', quantity: 2, price: 8.00 },
    ],
    total: 16.00,
    status: 'ready' as const,
    deliveryType: 'pickup',
    paymentMethod: 'Binance',
    createdAt: new Date(Date.now() - 45 * 60000),
  },
  {
    id: 'ORD-005',
    customer: 'Elena Gómez',
    phone: '0412-3334455',
    items: [
      { name: 'Promo 4 Hamburguesas', quantity: 1, price: 28.00 },
    ],
    total: 28.00,
    status: 'delivered' as const,
    deliveryType: 'delivery',
    address: 'Centro Comercial Sambil, Local 45',
    paymentMethod: 'Pago Móvil',
    createdAt: new Date(Date.now() - 90 * 60000),
  },
];

const statusActions = {
  pending: { next: 'confirmed', label: 'Confirmar', icon: CheckCircle },
  confirmed: { next: 'preparing', label: 'Preparar', icon: ChefHat },
  preparing: { next: 'ready', label: 'Listo', icon: Package },
  ready: { next: 'delivered', label: 'Entregar', icon: Truck },
  delivered: null,
  cancelled: null,
};

export default function PedidosPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<typeof orders[0] | null>(null);
  const [ordersList, setOrdersList] = useState(orders);

  const filteredOrders = ordersList.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const updateOrderStatus = (orderId: string, newStatus: string) => {
    setOrdersList((prev) =>
      prev.map((order) =>
        order.id === orderId ? { ...order, status: newStatus as any } : order
      )
    );
    toast.success(`Pedido ${orderId} actualizado`);
    setSelectedOrder(null);
  };

  const cancelOrder = (orderId: string) => {
    setOrdersList((prev) =>
      prev.map((order) =>
        order.id === orderId ? { ...order, status: 'cancelled' as const } : order
      )
    );
    toast.success(`Pedido ${orderId} cancelado`);
    setSelectedOrder(null);
  };

  const getStatusCount = (status: string) =>
    ordersList.filter((o) => o.status === status).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="heading-2 text-gray-900">Pedidos</h1>
        <p className="text-gray-600 mt-1">Gestiona los pedidos del restaurante</p>
      </div>

      {/* Status Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {[
          { value: 'all', label: 'Todos', count: ordersList.length },
          { value: 'pending', label: 'Pendientes', count: getStatusCount('pending') },
          { value: 'confirmed', label: 'Confirmados', count: getStatusCount('confirmed') },
          { value: 'preparing', label: 'Preparando', count: getStatusCount('preparing') },
          { value: 'ready', label: 'Listos', count: getStatusCount('ready') },
          { value: 'delivered', label: 'Entregados', count: getStatusCount('delivered') },
        ].map((tab) => (
          <button
            key={tab.value}
            onClick={() => setStatusFilter(tab.value)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${
              statusFilter === tab.value
                ? 'bg-celeste-500 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {tab.label}
            <span
              className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                statusFilter === tab.value
                  ? 'bg-white/20 text-white'
                  : 'bg-gray-200 text-gray-600'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <Input
            placeholder="Buscar por número de pedido o cliente..."
            icon={<Search className="w-5 h-5" />}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </CardContent>
      </Card>

      {/* Orders Grid */}
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredOrders.map((order, index) => {
          const action = statusActions[order.status];
          return (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-gray-900">{order.id}</h3>
                      <p className="text-sm text-gray-500">
                        {formatDate(order.createdAt, { timeStyle: 'short' })}
                      </p>
                    </div>
                    <OrderStatusBadge status={order.status} />
                  </div>

                  {/* Customer */}
                  <div className="mb-4">
                    <p className="font-medium text-gray-900">{order.customer}</p>
                    <p className="text-sm text-gray-500">{order.phone}</p>
                    {order.deliveryType === 'delivery' && (
                      <p className="text-sm text-gray-500 mt-1 flex items-center gap-1">
                        <Truck className="w-4 h-4" />
                        {order.address}
                      </p>
                    )}
                  </div>

                  {/* Items */}
                  <div className="space-y-1 mb-4">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span className="text-gray-600">
                          {item.quantity}x {item.name}
                        </span>
                        <span className="font-medium">
                          {formatCurrency(item.price * item.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Total & Payment */}
                  <div className="flex items-center justify-between pt-4 border-t">
                    <div>
                      <p className="text-xs text-gray-500">{order.paymentMethod}</p>
                      <p className="text-lg font-bold text-celeste-600">
                        {formatCurrency(order.total)}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedOrder(order)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      {action && (
                        <Button
                          variant="primary"
                          size="sm"
                          onClick={() => updateOrderStatus(order.id, action.next)}
                        >
                          <action.icon className="w-4 h-4 mr-1" />
                          {action.label}
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {filteredOrders.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Package className="w-12 h-12 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500">No se encontraron pedidos</p>
          </CardContent>
        </Card>
      )}

      {/* Order Detail Modal */}
      <Modal
        isOpen={!!selectedOrder}
        onClose={() => setSelectedOrder(null)}
        title={`Pedido ${selectedOrder?.id}`}
        size="lg"
      >
        {selectedOrder && (
          <div className="space-y-6">
            {/* Status */}
            <div className="flex items-center justify-between">
              <OrderStatusBadge status={selectedOrder.status} />
              <span className="text-sm text-gray-500">
                {formatDate(selectedOrder.createdAt)}
              </span>
            </div>

            {/* Customer Info */}
            <div className="p-4 bg-gray-50 rounded-xl space-y-2">
              <h4 className="font-semibold text-gray-900">Cliente</h4>
              <p className="text-gray-700">{selectedOrder.customer}</p>
              <p className="text-gray-600">{selectedOrder.phone}</p>
              {selectedOrder.deliveryType === 'delivery' && (
                <p className="text-gray-600 flex items-center gap-2">
                  <Truck className="w-4 h-4" />
                  {selectedOrder.address}
                </p>
              )}
            </div>

            {/* Items */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Productos</h4>
              <div className="space-y-2">
                {selectedOrder.items.map((item, i) => (
                  <div
                    key={i}
                    className="flex justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <span>
                      {item.quantity}x {item.name}
                    </span>
                    <span className="font-medium">
                      {formatCurrency(item.price * item.quantity)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Total */}
            <div className="flex justify-between items-center p-4 bg-celeste-50 rounded-xl">
              <div>
                <p className="text-sm text-celeste-600">Método de pago</p>
                <p className="font-medium text-celeste-700">
                  {selectedOrder.paymentMethod}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-celeste-600">Total</p>
                <p className="text-2xl font-bold text-celeste-700">
                  {formatCurrency(selectedOrder.total)}
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              {statusActions[selectedOrder.status] && (
                <Button
                  variant="primary"
                  fullWidth
                  onClick={() =>
                    updateOrderStatus(
                      selectedOrder.id,
                      statusActions[selectedOrder.status]!.next
                    )
                  }
                >
                  {(() => {
                    const Icon = statusActions[selectedOrder.status]!.icon;
                    return <Icon className="w-5 h-5 mr-2" />;
                  })()}
                  {statusActions[selectedOrder.status]!.label}
                </Button>
              )}
              {selectedOrder.status !== 'delivered' &&
                selectedOrder.status !== 'cancelled' && (
                  <Button
                    variant="danger"
                    onClick={() => cancelOrder(selectedOrder.id)}
                  >
                    <XCircle className="w-5 h-5 mr-2" />
                    Cancelar
                  </Button>
                )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
