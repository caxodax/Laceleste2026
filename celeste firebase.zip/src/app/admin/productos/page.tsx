'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  Search,
  Edit,
  Trash2,
  MoreVertical,
  Eye,
  EyeOff,
  Package,
} from 'lucide-react';
import { Button, Input, Card, CardContent, Badge, Modal, ConfirmModal } from '@/components/ui';
import { formatCurrency } from '@/lib/utils';
import { products as initialProducts, categories } from '@/data/menu';
import toast from 'react-hot-toast';

export default function ProductosPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [productsList, setProductsList] = useState(initialProducts);
  const [editingProduct, setEditingProduct] = useState<typeof initialProducts[0] | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const filteredProducts = productsList.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const toggleAvailability = (productId: string) => {
    setProductsList((prev) =>
      prev.map((p) =>
        p.id === productId ? { ...p, available: !p.available } : p
      )
    );
    toast.success('Disponibilidad actualizada');
  };

  const deleteProduct = (productId: string) => {
    setProductsList((prev) => prev.filter((p) => p.id !== productId));
    setDeleteConfirm(null);
    toast.success('Producto eliminado');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="heading-2 text-gray-900">Productos</h1>
          <p className="text-gray-600 mt-1">Gestiona el menú del restaurante</p>
        </div>
        <Button variant="primary" icon={<Plus className="w-5 h-5" />}>
          Nuevo Producto
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4">
          <p className="text-sm text-gray-500">Total Productos</p>
          <p className="text-2xl font-bold text-gray-900">{productsList.length}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-gray-500">Disponibles</p>
          <p className="text-2xl font-bold text-green-600">
            {productsList.filter((p) => p.available).length}
          </p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-gray-500">No Disponibles</p>
          <p className="text-2xl font-bold text-red-600">
            {productsList.filter((p) => !p.available).length}
          </p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-gray-500">Categorías</p>
          <p className="text-2xl font-bold text-celeste-600">{categories.length}</p>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Buscar productos..."
                icon={<Search className="w-5 h-5" />}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-celeste-500 focus:outline-none"
            >
              <option value="all">Todas las categorías</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.icon} {cat.name}
                </option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Products Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filteredProducts.map((product, index) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
          >
            <Card className={`h-full ${!product.available ? 'opacity-60' : ''}`}>
              <CardContent className="p-4">
                {/* Image */}
                <div className="relative w-full h-32 mb-4 rounded-xl overflow-hidden bg-gray-100">
                  {product.image ? (
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl">
                      🍔
                    </div>
                  )}
                  {product.featured && (
                    <span className="absolute top-2 left-2 badge-gold text-xs">
                      ⭐ Popular
                    </span>
                  )}
                  {!product.available && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <span className="text-white text-sm font-medium">No disponible</span>
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="mb-4">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-semibold text-gray-900">{product.name}</h3>
                    <span className="text-lg font-bold text-celeste-600">
                      {formatCurrency(product.price)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1 line-clamp-2">
                    {product.description}
                  </p>
                  <Badge variant="gray" size="sm" className="mt-2">
                    {categories.find((c) => c.id === product.category)?.name}
                  </Badge>
                </div>

                {/* Actions */}
                <div className="flex gap-2 pt-4 border-t">
                  <button
                    onClick={() => toggleAvailability(product.id)}
                    className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-colors ${
                      product.available
                        ? 'bg-green-50 text-green-600 hover:bg-green-100'
                        : 'bg-red-50 text-red-600 hover:bg-red-100'
                    }`}
                  >
                    {product.available ? (
                      <>
                        <Eye className="w-4 h-4" />
                        Visible
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-4 h-4" />
                        Oculto
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => setEditingProduct(product)}
                    className="p-2 text-gray-500 hover:text-celeste-600 hover:bg-celeste-50 rounded-lg transition-colors"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(product.id)}
                    className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Package className="w-12 h-12 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500">No se encontraron productos</p>
          </CardContent>
        </Card>
      )}

      {/* Edit Modal */}
      <Modal
        isOpen={!!editingProduct}
        onClose={() => setEditingProduct(null)}
        title="Editar Producto"
        size="lg"
      >
        {editingProduct && (
          <div className="space-y-4">
            <Input
              label="Nombre"
              defaultValue={editingProduct.name}
            />
            <Input
              label="Precio"
              type="number"
              step="0.01"
              defaultValue={editingProduct.price}
            />
            <div>
              <label className="label">Categoría</label>
              <select
                defaultValue={editingProduct.category}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-celeste-500 focus:outline-none"
              >
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.icon} {cat.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Descripción</label>
              <textarea
                defaultValue={editingProduct.description}
                rows={3}
                className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-celeste-500 focus:outline-none resize-none"
              />
            </div>
            <div className="flex gap-3 pt-4">
              <Button variant="ghost" onClick={() => setEditingProduct(null)}>
                Cancelar
              </Button>
              <Button
                variant="primary"
                className="flex-1"
                onClick={() => {
                  toast.success('Producto actualizado');
                  setEditingProduct(null);
                }}
              >
                Guardar Cambios
              </Button>
            </div>
          </div>
        )}
      </Modal>

      {/* Delete Confirmation */}
      <ConfirmModal
        isOpen={!!deleteConfirm}
        onClose={() => setDeleteConfirm(null)}
        onConfirm={() => deleteConfirm && deleteProduct(deleteConfirm)}
        title="Eliminar Producto"
        message="¿Estás seguro de que deseas eliminar este producto? Esta acción no se puede deshacer."
        confirmText="Eliminar"
        variant="danger"
      />
    </div>
  );
}
