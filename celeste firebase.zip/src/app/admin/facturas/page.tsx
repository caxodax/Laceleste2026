'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  Search,
  Filter,
  Download,
  Eye,
  Printer,
  MoreVertical,
  FileText,
} from 'lucide-react';
import Link from 'next/link';
import { Button, Input, Card, CardContent, InvoiceStatusBadge, Modal } from '@/components/ui';
import { formatCurrency, formatDate } from '@/lib/utils';

// Datos de ejemplo
const invoices = [
  {
    id: 'INV-2401-0001',
    orderId: 'ORD-001',
    customer: 'María García',
    customerRif: 'V-12345678-9',
    total: 52.78,
    status: 'paid' as const,
    createdAt: new Date('2024-01-30T10:30:00'),
    paidAt: new Date('2024-01-30T10:35:00'),
  },
  {
    id: 'INV-2401-0002',
    orderId: 'ORD-002',
    customer: 'Carlos Rodríguez',
    customerRif: 'V-98765432-1',
    total: 32.48,
    status: 'issued' as const,
    createdAt: new Date('2024-01-30T11:00:00'),
  },
  {
    id: 'INV-2401-0003',
    orderId: 'ORD-003',
    customer: 'Ana Martínez',
    customerRif: 'V-11223344-5',
    total: 83.52,
    status: 'paid' as const,
    createdAt: new Date('2024-01-30T12:15:00'),
    paidAt: new Date('2024-01-30T12:20:00'),
  },
  {
    id: 'INV-2401-0004',
    orderId: 'ORD-004',
    customer: 'Luis Pérez',
    total: 17.40,
    status: 'draft' as const,
    createdAt: new Date('2024-01-30T14:00:00'),
  },
  {
    id: 'INV-2401-0005',
    orderId: 'ORD-005',
    customer: 'Elena Gómez',
    customerRif: 'V-55667788-0',
    total: 45.00,
    status: 'cancelled' as const,
    createdAt: new Date('2024-01-29T16:30:00'),
  },
];

export default function FacturasPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedInvoice, setSelectedInvoice] = useState<typeof invoices[0] | null>(null);

  const filteredInvoices = invoices.filter((invoice) => {
    const matchesSearch =
      invoice.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.customer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || invoice.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalPaid = invoices
    .filter((i) => i.status === 'paid')
    .reduce((sum, i) => sum + i.total, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="heading-2 text-gray-900">Facturas</h1>
          <p className="text-gray-600 mt-1">Gestiona las facturas del restaurante</p>
        </div>
        <Link href="/admin/facturas/nueva">
          <Button variant="primary" icon={<Plus className="w-5 h-5" />}>
            Nueva Factura
          </Button>
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-4">
          <p className="text-sm text-gray-500">Total Facturas</p>
          <p className="text-2xl font-bold text-gray-900">{invoices.length}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-gray-500">Pagadas</p>
          <p className="text-2xl font-bold text-green-600">
            {invoices.filter((i) => i.status === 'paid').length}
          </p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-gray-500">Pendientes</p>
          <p className="text-2xl font-bold text-yellow-600">
            {invoices.filter((i) => i.status === 'issued').length}
          </p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-gray-500">Total Recaudado</p>
          <p className="text-2xl font-bold text-celeste-600">{formatCurrency(totalPaid)}</p>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Buscar por número o cliente..."
                icon={<Search className="w-5 h-5" />}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-4 py-2 border-2 border-gray-200 rounded-xl focus:border-celeste-500 focus:outline-none"
              >
                <option value="all">Todos los estados</option>
                <option value="draft">Borrador</option>
                <option value="issued">Emitida</option>
                <option value="paid">Pagada</option>
                <option value="cancelled">Anulada</option>
              </select>
              <Button variant="secondary" icon={<Download className="w-5 h-5" />}>
                Exportar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b bg-gray-50">
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Factura
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Cliente
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  RIF
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Total
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Estado
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase">
                  Fecha
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredInvoices.map((invoice, index) => (
                <motion.tr
                  key={invoice.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="hover:bg-gray-50 transition-colors"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-celeste-100 flex items-center justify-center">
                        <FileText className="w-5 h-5 text-celeste-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{invoice.id}</p>
                        <p className="text-xs text-gray-500">Pedido: {invoice.orderId}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-700">{invoice.customer}</td>
                  <td className="px-6 py-4 text-gray-500 text-sm">
                    {invoice.customerRif || '-'}
                  </td>
                  <td className="px-6 py-4 font-semibold text-gray-900">
                    {formatCurrency(invoice.total)}
                  </td>
                  <td className="px-6 py-4">
                    <InvoiceStatusBadge status={invoice.status} />
                  </td>
                  <td className="px-6 py-4 text-gray-500 text-sm">
                    {formatDate(invoice.createdAt)}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setSelectedInvoice(invoice)}
                        className="p-2 text-gray-500 hover:text-celeste-600 hover:bg-celeste-50 rounded-lg transition-colors"
                        title="Ver"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        className="p-2 text-gray-500 hover:text-celeste-600 hover:bg-celeste-50 rounded-lg transition-colors"
                        title="Imprimir"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                      <button
                        className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                        title="Más opciones"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredInvoices.length === 0 && (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500">No se encontraron facturas</p>
          </div>
        )}
      </Card>

      {/* Invoice Preview Modal */}
      <Modal
        isOpen={!!selectedInvoice}
        onClose={() => setSelectedInvoice(null)}
        title={`Factura ${selectedInvoice?.id}`}
        size="lg"
      >
        {selectedInvoice && (
          <div className="space-y-6">
            {/* Invoice Header */}
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-logo text-2xl text-celeste-600">La Celeste</h3>
                <p className="text-sm text-gray-500">Hamburguesas Artesanales</p>
              </div>
              <InvoiceStatusBadge status={selectedInvoice.status} />
            </div>

            {/* Customer Info */}
            <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-xl">
              <div>
                <p className="text-sm text-gray-500">Cliente</p>
                <p className="font-medium">{selectedInvoice.customer}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">RIF</p>
                <p className="font-medium">{selectedInvoice.customerRif || 'N/A'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Fecha de Emisión</p>
                <p className="font-medium">{formatDate(selectedInvoice.createdAt)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Pedido</p>
                <p className="font-medium">{selectedInvoice.orderId}</p>
              </div>
            </div>

            {/* Total */}
            <div className="flex justify-between items-center p-4 bg-celeste-50 rounded-xl">
              <span className="text-lg font-medium text-celeste-700">Total</span>
              <span className="text-2xl font-bold text-celeste-600">
                {formatCurrency(selectedInvoice.total)}
              </span>
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              <Button variant="primary" icon={<Printer className="w-5 h-5" />} fullWidth>
                Imprimir
              </Button>
              <Button variant="secondary" icon={<Download className="w-5 h-5" />} fullWidth>
                Descargar PDF
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
