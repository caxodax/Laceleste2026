'use client';

import { motion } from 'framer-motion';
import {
  DollarSign,
  ShoppingBag,
  FileText,
  TrendingUp,
  Clock,
  CheckCircle,
  AlertCircle,
} from 'lucide-react';
import { StatCard, Card, CardContent, CardHeader, OrderStatusBadge } from '@/components/ui';
import { formatCurrency, formatDate } from '@/lib/utils';

// Datos de ejemplo para el dashboard
const stats = [
  {
    title: 'Ventas del Día',
    value: formatCurrency(1250.00),
    icon: <DollarSign className="w-6 h-6" />,
    trend: { value: 12, isPositive: true },
    color: 'celeste' as const,
  },
  {
    title: 'Pedidos Hoy',
    value: '24',
    icon: <ShoppingBag className="w-6 h-6" />,
    trend: { value: 8, isPositive: true },
    color: 'gold' as const,
  },
  {
    title: 'Facturas Emitidas',
    value: '18',
    icon: <FileText className="w-6 h-6" />,
    trend: { value: 5, isPositive: true },
    color: 'green' as const,
  },
  {
    title: 'Ticket Promedio',
    value: formatCurrency(52.08),
    icon: <TrendingUp className="w-6 h-6" />,
    trend: { value: 3, isPositive: false },
    color: 'celeste' as const,
  },
];

const recentOrders = [
  {
    id: 'ORD-001',
    customer: 'María García',
    items: 3,
    total: 45.50,
    status: 'preparing' as const,
    time: new Date(Date.now() - 15 * 60000),
  },
  {
    id: 'ORD-002',
    customer: 'Carlos Rodríguez',
    items: 2,
    total: 28.00,
    status: 'ready' as const,
    time: new Date(Date.now() - 30 * 60000),
  },
  {
    id: 'ORD-003',
    customer: 'Ana Martínez',
    items: 5,
    total: 72.00,
    status: 'pending' as const,
    time: new Date(Date.now() - 5 * 60000),
  },
  {
    id: 'ORD-004',
    customer: 'Luis Pérez',
    items: 1,
    total: 15.00,
    status: 'delivered' as const,
    time: new Date(Date.now() - 60 * 60000),
  },
];

const topProducts = [
  { name: 'La Bombonera', sales: 45, revenue: 427.50 },
  { name: 'San Telmo', sales: 38, revenue: 323.00 },
  { name: 'Caballito', sales: 32, revenue: 256.00 },
  { name: 'Tequeños 10 uds', sales: 28, revenue: 140.00 },
  { name: 'La Monumental', sales: 25, revenue: 250.00 },
];

export default function AdminDashboard() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="heading-2 text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-1">Bienvenido al panel de administración de La Celeste</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <StatCard {...stat} />
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2"
        >
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Pedidos Recientes</h2>
              <a href="/admin/pedidos" className="text-sm text-celeste-600 hover:text-celeste-700">
                Ver todos →
              </a>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b bg-gray-50">
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                        Pedido
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                        Cliente
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                        Total
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                        Estado
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase">
                        Hora
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {recentOrders.map((order) => (
                      <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4">
                          <span className="font-medium text-gray-900">{order.id}</span>
                        </td>
                        <td className="px-6 py-4 text-gray-600">{order.customer}</td>
                        <td className="px-6 py-4 font-medium text-gray-900">
                          {formatCurrency(order.total)}
                        </td>
                        <td className="px-6 py-4">
                          <OrderStatusBadge status={order.status} />
                        </td>
                        <td className="px-6 py-4 text-gray-500 text-sm">
                          {formatDate(order.time, { timeStyle: 'short' })}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Top Products */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <h2 className="text-lg font-semibold text-gray-900">Productos Top</h2>
            </CardHeader>
            <CardContent className="p-0">
              <ul className="divide-y divide-gray-100">
                {topProducts.map((product, index) => (
                  <li key={product.name} className="px-6 py-4 flex items-center gap-4">
                    <span
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        index === 0
                          ? 'bg-gold-100 text-gold-700'
                          : index === 1
                          ? 'bg-gray-200 text-gray-700'
                          : index === 2
                          ? 'bg-orange-100 text-orange-700'
                          : 'bg-gray-100 text-gray-600'
                      }`}
                    >
                      {index + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 truncate">{product.name}</p>
                      <p className="text-sm text-gray-500">{product.sales} vendidos</p>
                    </div>
                    <span className="font-semibold text-celeste-600">
                      {formatCurrency(product.revenue)}
                    </span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
      >
        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Acciones Rápidas</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <a
                href="/admin/facturas/nueva"
                className="flex flex-col items-center gap-2 p-4 bg-celeste-50 rounded-xl hover:bg-celeste-100 transition-colors"
              >
                <FileText className="w-8 h-8 text-celeste-600" />
                <span className="text-sm font-medium text-celeste-700">Nueva Factura</span>
              </a>
              <a
                href="/admin/productos/nuevo"
                className="flex flex-col items-center gap-2 p-4 bg-gold-50 rounded-xl hover:bg-gold-100 transition-colors"
              >
                <ShoppingBag className="w-8 h-8 text-gold-600" />
                <span className="text-sm font-medium text-gold-700">Nuevo Producto</span>
              </a>
              <a
                href="/admin/pedidos?status=pending"
                className="flex flex-col items-center gap-2 p-4 bg-orange-50 rounded-xl hover:bg-orange-100 transition-colors"
              >
                <Clock className="w-8 h-8 text-orange-600" />
                <span className="text-sm font-medium text-orange-700">Pedidos Pendientes</span>
              </a>
              <a
                href="/admin/reportes"
                className="flex flex-col items-center gap-2 p-4 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
              >
                <TrendingUp className="w-8 h-8 text-green-600" />
                <span className="text-sm font-medium text-green-700">Ver Reportes</span>
              </a>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
