'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight, Star, Clock, MapPin, Phone } from 'lucide-react';
import { Header, Footer, WhatsAppButton } from '@/components/layout';
import { Button, MenuCard } from '@/components/ui';
import { products, categories, restaurantSettings } from '@/data/menu';
import { useCartStore } from '@/store/cartStore';
import toast from 'react-hot-toast';

export default function HomePage() {
  const addItem = useCartStore((state) => state.addItem);
  const featuredProducts = products.filter((p) => p.featured).slice(0, 4);

  const handleAddToCart = (product: any) => {
    addItem(product, 1);
    toast.success(`${product.name} agregado al carrito`, {
      icon: '🍔',
      style: {
        borderRadius: '12px',
        background: '#0ea5e9',
        color: '#fff',
      },
    });
  };

  return (
    <>
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          {/* Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-celeste-600 via-celeste-500 to-celeste-700" />
          
          {/* Decorative elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-white/10 rounded-full blur-3xl" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gold-400/20 rounded-full blur-3xl" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-white/5 rounded-full" />
          </div>

          {/* Content */}
          <div className="container-app relative z-10 py-32">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Text */}
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="text-center lg:text-left"
              >
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-white mb-6"
                >
                  <Star className="w-4 h-4 text-gold-400 fill-gold-400" />
                  <span className="text-sm font-medium">Las mejores de Barquisimeto</span>
                </motion.div>

                <h1 className="heading-1 text-white mb-6">
                  Hamburguesas
                  <span className="block text-gold-400">Artesanales</span>
                </h1>

                <p className="text-xl text-white/90 mb-8 max-w-lg mx-auto lg:mx-0">
                  Inspiradas en los sabores de Argentina 🇦🇷
                  <br />
                  Hechas con amor y los mejores ingredientes
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                  <Link href="/menu">
                    <Button variant="gold" size="lg" icon={<ArrowRight className="w-5 h-5" />} iconPosition="right">
                      Ver Menú
                    </Button>
                  </Link>
                  <Link href="/pedido">
                    <Button variant="secondary" size="lg" className="bg-white/10 border-white text-white hover:bg-white hover:text-celeste-600">
                      Hacer Pedido
                    </Button>
                  </Link>
                </div>

                {/* Info badges */}
                <div className="flex flex-wrap gap-4 mt-8 justify-center lg:justify-start">
                  <div className="flex items-center gap-2 text-white/80">
                    <Clock className="w-5 h-5" />
                    <span className="text-sm">5PM - 12AM</span>
                  </div>
                  <div className="flex items-center gap-2 text-white/80">
                    <MapPin className="w-5 h-5" />
                    <span className="text-sm">Barquisimeto</span>
                  </div>
                  <div className="flex items-center gap-2 text-white/80">
                    <Phone className="w-5 h-5" />
                    <span className="text-sm">{restaurantSettings.phone}</span>
                  </div>
                </div>
              </motion.div>

              {/* Hero Image/Logo */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="relative hidden lg:block"
              >
                <div className="relative w-96 h-96 mx-auto">
                  {/* Glow effect */}
                  <div className="absolute inset-0 bg-gold-400/30 rounded-full blur-3xl animate-pulse" />
                  
                  {/* Main circle */}
                  <div className="relative w-full h-full rounded-full bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-sm border border-white/20 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-celeste-400 to-celeste-600 flex items-center justify-center shadow-2xl">
                        <span className="font-logo text-white text-6xl">C</span>
                      </div>
                      <h2 className="font-logo text-4xl text-white">La Celeste</h2>
                      <p className="text-white/70 text-sm mt-1">Hamburguesas</p>
                    </div>
                  </div>

                  {/* Floating elements */}
                  <motion.div
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity }}
                    className="absolute -top-4 -right-4 text-6xl"
                  >
                    🍔
                  </motion.div>
                  <motion.div
                    animate={{ y: [0, 10, 0] }}
                    transition={{ duration: 2.5, repeat: Infinity }}
                    className="absolute -bottom-4 -left-4 text-5xl"
                  >
                    🍟
                  </motion.div>
                  <motion.div
                    animate={{ y: [0, -8, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="absolute top-1/2 -right-8 text-4xl"
                  >
                    🧀
                  </motion.div>
                </div>
              </motion.div>
            </div>
          </div>

          {/* Scroll indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2"
          >
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center pt-2"
            >
              <div className="w-1.5 h-3 bg-white/70 rounded-full" />
            </motion.div>
          </motion.div>
        </section>

        {/* Featured Products */}
        <section className="section bg-white">
          <div className="container-app">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <span className="badge-gold mb-4">⭐ Lo más pedido</span>
              <h2 className="heading-2 text-gray-900 mb-4">Nuestros Favoritos</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Las hamburguesas que nuestros clientes más aman. 
                Preparadas con ingredientes frescos y mucho sabor.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <MenuCard
                    title={product.name}
                    description={product.description}
                    price={product.price}
                    image={product.image}
                    badge="⭐ Popular"
                    available={product.available}
                    onAddToCart={() => handleAddToCart(product)}
                  />
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-center mt-10"
            >
              <Link href="/menu">
                <Button variant="primary" size="lg" icon={<ArrowRight className="w-5 h-5" />} iconPosition="right">
                  Ver Menú Completo
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* Categories Preview */}
        <section className="section bg-cream-50">
          <div className="container-app">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="heading-2 text-gray-900 mb-4">Nuestro Menú</h2>
              <p className="text-gray-600">Explora todas nuestras categorías</p>
            </motion.div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {categories.map((category, index) => (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link href={`/menu#${category.id}`}>
                    <div className="card-hover p-6 text-center group">
                      <span className="text-5xl mb-4 block group-hover:scale-110 transition-transform">
                        {category.icon}
                      </span>
                      <h3 className="font-semibold text-gray-900">{category.name}</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        {products.filter((p) => p.category === category.id).length} items
                      </p>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="section bg-gradient-to-r from-celeste-600 to-celeste-700 text-white">
          <div className="container-app text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="heading-2 mb-4">¿Listo para ordenar?</h2>
              <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
                Haz tu pedido ahora y disfruta de las mejores hamburguesas de Barquisimeto
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/pedido">
                  <Button variant="gold" size="lg">
                    Hacer Pedido Online
                  </Button>
                </Link>
                <a
                  href={`https://wa.me/${restaurantSettings.whatsapp}?text=${encodeURIComponent('¡Hola! Quiero hacer un pedido 🍔')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="secondary" size="lg" className="bg-white/10 border-white text-white hover:bg-white hover:text-celeste-600">
                    Pedir por WhatsApp
                  </Button>
                </a>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Payment Methods */}
        <section className="section bg-white">
          <div className="container-app">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-10"
            >
              <h2 className="heading-3 text-gray-900 mb-4">Métodos de Pago</h2>
              <p className="text-gray-600">Aceptamos múltiples formas de pago para tu comodidad</p>
            </motion.div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {restaurantSettings.paymentMethods.map((method, index) => (
                <motion.div
                  key={method.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="card p-4 text-center"
                >
                  <span className="text-3xl mb-2 block">{method.icon}</span>
                  <h4 className="font-semibold text-gray-900">{method.name}</h4>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
      <WhatsAppButton />
    </>
  );
}
