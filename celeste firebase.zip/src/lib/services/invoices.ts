import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  query,
  where,
  orderBy,
  Timestamp,
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Invoice } from '@/types';
import { generateInvoiceNumber } from '@/lib/utils';

const COLLECTION = 'invoices';

export async function getInvoices(statusFilter?: string): Promise<Invoice[]> {
  let q;
  
  if (statusFilter && statusFilter !== 'all') {
    q = query(
      collection(db, COLLECTION),
      where('status', '==', statusFilter),
      orderBy('createdAt', 'desc')
    );
  } else {
    q = query(collection(db, COLLECTION), orderBy('createdAt', 'desc'));
  }
  
  const snapshot = await getDocs(q);
  
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate(),
    updatedAt: doc.data().updatedAt?.toDate(),
    issuedAt: doc.data().issuedAt?.toDate(),
    paidAt: doc.data().paidAt?.toDate(),
  })) as Invoice[];
}

export async function getInvoice(id: string): Promise<Invoice | null> {
  const docRef = doc(db, COLLECTION, id);
  const docSnap = await getDoc(docRef);
  
  if (!docSnap.exists()) return null;
  
  return {
    id: docSnap.id,
    ...docSnap.data(),
    createdAt: docSnap.data().createdAt?.toDate(),
    updatedAt: docSnap.data().updatedAt?.toDate(),
    issuedAt: docSnap.data().issuedAt?.toDate(),
    paidAt: docSnap.data().paidAt?.toDate(),
  } as Invoice;
}

export async function createInvoice(
  data: Omit<Invoice, 'id' | 'invoiceNumber' | 'createdAt' | 'updatedAt'>
): Promise<string> {
  const invoiceNumber = generateInvoiceNumber();
  
  const docRef = await addDoc(collection(db, COLLECTION), {
    ...data,
    invoiceNumber,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });
  
  return docRef.id;
}

export async function updateInvoice(id: string, data: Partial<Invoice>): Promise<void> {
  const docRef = doc(db, COLLECTION, id);
  await updateDoc(docRef, {
    ...data,
    updatedAt: Timestamp.now(),
  });
}

export async function issueInvoice(id: string): Promise<void> {
  const docRef = doc(db, COLLECTION, id);
  await updateDoc(docRef, {
    status: 'issued',
    issuedAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });
}

export async function markInvoiceAsPaid(id: string, paymentReference?: string): Promise<void> {
  const docRef = doc(db, COLLECTION, id);
  await updateDoc(docRef, {
    status: 'paid',
    paymentReference,
    paidAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });
}

export async function cancelInvoice(id: string): Promise<void> {
  const docRef = doc(db, COLLECTION, id);
  await updateDoc(docRef, {
    status: 'cancelled',
    updatedAt: Timestamp.now(),
  });
}

export async function getInvoicesByDateRange(
  startDate: Date,
  endDate: Date
): Promise<Invoice[]> {
  const q = query(
    collection(db, COLLECTION),
    where('createdAt', '>=', Timestamp.fromDate(startDate)),
    where('createdAt', '<=', Timestamp.fromDate(endDate)),
    orderBy('createdAt', 'desc')
  );
  
  const snapshot = await getDocs(q);
  
  return snapshot.docs.map((doc) => ({
    id: doc.id,
    ...doc.data(),
    createdAt: doc.data().createdAt?.toDate(),
    updatedAt: doc.data().updatedAt?.toDate(),
    issuedAt: doc.data().issuedAt?.toDate(),
    paidAt: doc.data().paidAt?.toDate(),
  })) as Invoice[];
}

export async function getTotalRevenue(startDate?: Date, endDate?: Date): Promise<number> {
  let invoices: Invoice[];
  
  if (startDate && endDate) {
    invoices = await getInvoicesByDateRange(startDate, endDate);
  } else {
    invoices = await getInvoices('paid');
  }
  
  return invoices
    .filter((inv) => inv.status === 'paid')
    .reduce((sum, inv) => sum + inv.total, 0);
}
