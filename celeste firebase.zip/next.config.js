/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export', // Para Firebase Hosting estático
  images: {
    unoptimized: true, // Necesario para export estático
  },
  trailingSlash: true,
}

module.exports = nextConfig
